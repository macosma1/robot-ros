<launch>
<param name="robot_description"
command="$(find xacro)/xacro --inorder $(find turtlebot3_description)/urdf/turtlebot3_burger_1cam180.urdf.xacro" />"
<group ns="agent1">
<param name="tf_prefix" value="agent1_tfs" />
<include file="$(find multi_robot)/launch/one_agent_1cam180.launch" >
    <arg name="init_pose" value="-x -4 -y 2 -z 0 -Y 3.63" />
    <arg name="agent_name"  value="agent1" />
</include>
<node pkg="pointcloud_to_laserscan" type="pointcloud_to_laserscan_node" name="pointcloud_to_laserscan">

        <remap from="agent1/cloud_in" to="agent1/camera/depth/points"/>
        <remap from="agent1/scan" to="agent1/camera"/>

        <rosparam>
            target_frame: camera_link 
            transform_tolerance: 0.01
            min_height: 0.0
            max_height: 1.0
            angle_min: -0.78539816339  
            angle_max:  0.78539816339  
            angle_increment: 0.1308996939
            scan_time: 1.0/30.0
            range_min: 0.00
            range_max: 3.5
            concurrency_level: 1
            use_inf: true
        </rosparam>
    </node> 
    <node pkg="ddrl_ge" type="camera_sync1.py" name="camera_sync1" output="screen" />


</group>

</launch>